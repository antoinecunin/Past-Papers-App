#!/bin/bash
set -euo pipefail

MODE=${1:-prod}

if [[ "$MODE" != "dev" && "$MODE" != "prod" ]]; then
  echo "❌ Usage: $0 [dev|prod]"
  echo "   dev:  Démarrage en mode développement avec hot reload (port configuré)"
  echo "   prod: Démarrage en mode production (port configuré)"
  exit 1
fi

echo "🚀 Démarrage de la plateforme d'annales en mode $MODE..."

if ! command -v docker &>/dev/null; then
  echo "❌ Docker n'est pas installé." ; exit 1
fi
if ! docker compose version &>/dev/null; then
  echo "❌ Docker Compose plugin manquant." ; exit 1
fi

# Configuration selon le mode
if [ "$MODE" = "dev" ]; then
  COMPOSE_FILE="docker-compose.dev.yml"
  ENV_FILE=".env.dev"
  CONTAINER_PREFIX="dev"
  NGINX_CONTAINER="annales-nginx-dev"
else
  COMPOSE_FILE="docker-compose.yml"
  ENV_FILE=".env"
  CONTAINER_PREFIX=""
  NGINX_CONTAINER="annales-nginx"
fi

# Charger les variables d'environnement pour obtenir les ports
set -a
source "$ENV_FILE"
set +a

# Vérification du fichier d'environnement
if [ ! -f "$ENV_FILE" ]; then
  if [ "$MODE" = "prod" ]; then
    echo "📝 Création du fichier .env depuis .env.example..."
    cp .env.example .env
    echo "⚠️  Éditez .env puis relancez si besoin."
  else
    echo "❌ Fichier $ENV_FILE manquant. Création automatique..."
    echo "📝 Le fichier $ENV_FILE a été créé automatiquement."
  fi
fi

echo "🔨 Build images ($MODE)..."
docker compose -f "$COMPOSE_FILE" --env-file "$ENV_FILE" build

echo "▶️  Démarrage des services ($MODE)..."
docker compose -f "$COMPOSE_FILE" --env-file "$ENV_FILE" up -d

echo "⏳ Attente des checks de santé..."
# attend que reverse-proxy soit healthy
for i in {1..60}; do
  if docker inspect --format='{{.State.Health.Status}}' "$NGINX_CONTAINER" 2>/dev/null | grep -q healthy; then
    break
  fi
  sleep 1
done

if curl -sf "http://localhost:$WEB_PORT/api/health" >/dev/null; then
  echo "✅ Services démarrés avec succès en mode $MODE!"
  echo "🌐 Interface web: http://localhost:$WEB_PORT"
  echo "📖 API docs:     http://localhost:$WEB_PORT/api/docs"
  echo "❤️  Health:      http://localhost:$WEB_PORT/api/health"
  
  if [ "$MODE" = "dev" ]; then
    echo ""
    echo "🔥 Mode développement actif:"
    echo "   - Hot reload activé pour Web et API"
    echo "   - API directe:    http://localhost:$API_EXTERNAL_PORT"
    echo "   - Web directe:    http://localhost:$VITE_PORT"
    echo "   - MongoDB:        localhost:$MONGO_EXTERNAL_PORT"
    echo "   - MinIO:          http://localhost:$MINIO_EXTERNAL_PORT"
    echo "   - MinIO Console:  http://localhost:$MINIO_CONSOLE_EXTERNAL_PORT"
  fi
else
  echo "❌ Reverse-proxy KO (port $WEB_PORT). Logs:"
  docker logs "$NGINX_CONTAINER" || true
  exit 1
fi
